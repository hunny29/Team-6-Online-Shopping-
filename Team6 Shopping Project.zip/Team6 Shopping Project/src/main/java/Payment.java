import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Payment")
public class Payment extends HttpServlet {
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("cno");
		String b=req.getParameter("month");
		String c=req.getParameter("year");
		String d=req.getParameter("cvv");
		
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		if(a.isEmpty()||b.isEmpty()||c.isEmpty()||d.isEmpty())
		{
			res.sendRedirect("p2.html");		
		}
		else
		{
			PreparedStatement ps=con.prepareStatement("insert into payment values(?,?,?,?)");
			ps.setString(1,a);
			ps.setString(2,b);
			ps.setString(3,c);
			ps.setString(4,d);
			ps.execute();
			res.sendRedirect("contact.html");
			
		}
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}

}
