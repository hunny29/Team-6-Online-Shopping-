import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/checkout")
public class checkout extends HttpServlet {
	@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("fullname");
		String b=req.getParameter("email");
		String c=req.getParameter("phoneno");
		String d=req.getParameter("address");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		if(a.isEmpty()||b.isEmpty()||c.isEmpty()||d.isEmpty())
		{
			res.sendRedirect("checkout.html");		
		}
		else 
		{
		 PreparedStatement ps=con.prepareStatement("insert into checkout values(?,?,?,?)");
			ps.setString(1,a);
			ps.setString(2,b);
			ps.setString(3,c);
			ps.setString(4,d);
			ps.execute();
			res.sendRedirect("p2.html");
		}
		
	}	
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		}
			}