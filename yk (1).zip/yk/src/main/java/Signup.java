import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Signup")
public class Signup extends HttpServlet {

	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("firstname");
		String b=req.getParameter("lastname");
		String c=req.getParameter("email");
		String d=req.getParameter("password");
		String e=req.getParameter("confirmpassword");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement ps=con.prepareStatement("select * from signup where email=?");
		ps.setString(1,c);
		ResultSet rs=ps.executeQuery();
		int x=0;
		while(rs.next())
		{
			x=1;//when there is data
		}
		if(x==1)
		{
			
			pw.println("Email already exists!");
		}
		else
		{
			PreparedStatement ps1=con.prepareStatement("insert into signup values(?,?,?,?,?)");
			ps1.setString(1,a);
			ps1.setString(2,b);
			ps1.setString(3,c);
			ps1.setString(4,d);
			ps1.setString(5,e);
			ps1.execute();
			res.sendRedirect("login.html");
			
		}
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
}
}