import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Feedback")
public class Feedback extends HttpServlet {

	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("firstname");
		String b=req.getParameter("lastname");
		String c=req.getParameter("email");
		String d=req.getParameter("feedback");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement ps1=con.prepareStatement("insert into feedback values(?,?,?,?)");
		ps1.setString(1,a);
		ps1.setString(2,b);
		ps1.setString(3,c);
		ps1.setString(4,d);
		ps1.execute();
		res.sendRedirect("feedback.html");
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
}
}