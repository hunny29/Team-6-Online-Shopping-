import java.util.*;
import java.sql.*;
public class AdminDao {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	
	public static int delete(String email){
		int status=0;
		try{
			Connection con=AdminDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from signup where email=?");
			ps.setString(1,email);
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static int delete1(String email){
		int status=0;
		try{
			Connection con=AdminDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from contactus where email=?");
			ps.setString(1,email);
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static int delete2(String email){
		int status=0;
		try{
			Connection con=AdminDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from feedback where email=?");
			ps.setString(1,email);
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	
}
